<?php

echo '这是' . Yii::$app->params['addon']['name'] . ' html5 页面';