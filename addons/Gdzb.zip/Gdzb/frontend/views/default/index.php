<?php

echo '这是' . Yii::$app->params['addon']['name'] . ' frontend 页面';