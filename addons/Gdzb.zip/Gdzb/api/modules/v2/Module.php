<?php

namespace addons\Gdzb\api\modules\v2;

/**
 * Class Module
 * @package addons\Gdzb\api\modules\v2 * @author jianyan74 <751393839@qq.com>
 */
class Module extends \yii\base\Module
{
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'addons\Gdzb\api\modules\v2\controllers';

    public function init()
    {
        parent::init();
    }
}